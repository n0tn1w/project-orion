#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export NODE_ENV=production
export PORT=${PORT:-4000}
export HOST=${HOST:-127.0.0.1}
export BACKEND_ORIGIN=${BACKEND_ORIGIN:-http://127.0.0.1:5000}
exec node -r ./server-with-logs.js server.js
